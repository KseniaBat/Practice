﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace statisticRequest
{
    public partial class Comment1 : Form
    {
        public Comment1()
        {
            InitializeComponent();
        }

        private void addComment_Load(object sender, EventArgs e)
        {
            loadComboBox();
        }

        public void loadComboBox()
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();

            date.OpenConnection();

            string queryRequest = "SELECT request_id FROM request";
            using (var cmd = new SqlCommand(queryRequest, date.Connection))
            using (var rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                    comboBox1.Items.Add(rdr["request_id"].ToString());
            }

            string querySpecialist = "SELECT full_name FROM specialist";
            using (var cmd = new SqlCommand(querySpecialist, date.Connection))
            using (var rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                    comboBox2.Items.Add(rdr["full_name"].ToString());
            }

            date.CloseConnection();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (!DateTime.TryParse(maskedTextBox1.Text, out DateTime commentDate))
            {
                MessageBox.Show("Введите корректную дату.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (comboBox1.SelectedItem == null || comboBox2.SelectedItem == null || string.IsNullOrWhiteSpace(richTextBox1.Text))
            {
                MessageBox.Show("Заполните все поля.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int requestId = Convert.ToInt32(comboBox1.SelectedItem.ToString());
            int specialistId = 0;
            string commentText = richTextBox1.Text.Trim();

            date.OpenConnection();

            string querySpecialistId = $@"SELECT specialist_id FROM specialist WHERE full_name = '{comboBox2.SelectedItem.ToString()}'";
            using (var cmd = new SqlCommand(querySpecialistId, date.Connection))
            specialistId = (int)cmd.ExecuteScalar();

            try
            {
                string query = @"
                                INSERT INTO comment (request_id, specialist_id, comment_description, comment_date)
                                VALUES (@request_id, @specialist_id, @description, @comment_date);
                ";

                SqlCommand command = new SqlCommand(query, date.Connection);
                command.Parameters.AddWithValue("@request_id", requestId);
                command.Parameters.AddWithValue("@specialist_id", specialistId);
                command.Parameters.AddWithValue("@description", commentText);
                command.Parameters.AddWithValue("@comment_date", commentDate);

                int result = command.ExecuteNonQuery();

                if (result > 0)
                {
                    MessageBox.Show("Комментарий добавлен!", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Ошибка при добавлении комментария.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении комментария: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                date.CloseConnection();
            }
        }

        private void maskedTextBoxDate_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
