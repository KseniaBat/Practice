﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace statisticRequest
{
    public partial class Comment2 : Form
    {
        public Comment2()
        {
            InitializeComponent();
        }

        private void editComment_Load(object sender, EventArgs e)
        {
            loadComboBox();
            loadComponent();
        }

        public void loadComboBox()
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();

            date.OpenConnection();

            string queryRequest = "SELECT request_id FROM request";
            using (var cmd = new SqlCommand(queryRequest, date.Connection))
            using (var rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                    comboBox1.Items.Add(rdr["request_id"].ToString());
            }

            string querySpecialist = "SELECT full_name FROM specialist";
            using (var cmd = new SqlCommand(querySpecialist, date.Connection))
            using (var rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                    comboBox2.Items.Add(rdr["full_name"].ToString());
            }

            date.CloseConnection();
        }

        public void loadComponent()
        {
            string query = @"
                            SELECT 
                                c.comment_id,
                                r.request_id,
                                s.full_name,
                                c.comment_description,
                                FORMAT(c.comment_date, 'dd.MM.yyyy') AS comment_date
                            FROM comment c
                            JOIN request r ON c.request_id = r.request_id
                            JOIN specialist s ON c.specialist_id = s.specialist_id
                            WHERE c.comment_id = @id;
            ";

            using (SqlCommand cmd = new SqlCommand(query, date.Connection))
            {
                cmd.Parameters.AddWithValue("@id", data.indexComment);

                date.OpenConnection();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        maskedTextBox1.Text = Convert.ToDateTime(reader["comment_date"]).ToString("dd.MM.yyyy");
                        comboBox1.SelectedItem = reader["request_id"].ToString();
                        comboBox2.SelectedItem = reader["full_name"].ToString();
                        richTextBox1.Text = reader["comment_description"].ToString();
                    }
                }

                date.CloseConnection();
            }
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (!DateTime.TryParse(maskedTextBox1.Text, out DateTime commentDate))
            {
                MessageBox.Show("Введите корректную дату.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (comboBox1.SelectedItem == null || comboBox2.SelectedItem == null || string.IsNullOrWhiteSpace(richTextBox1.Text))
            {
                MessageBox.Show("Заполните все поля.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            date.OpenConnection();

            int requestId = Convert.ToInt32(comboBox1.SelectedItem.ToString());
            int specialistId = 0;
            string commentText = richTextBox1.Text.Trim();

            date.OpenConnection();

            string querySpecialistId = $@"SELECT specialist_id FROM specialist WHERE full_name = '{comboBox2.SelectedItem.ToString()}'";
            using (var cmd = new SqlCommand(querySpecialistId, date.Connection))
            specialistId = (int)cmd.ExecuteScalar();

            try
            {
                string query = @"
                                UPDATE comment
                                SET
                                    request_id = @request_id,
                                    specialist_id = @specialist_id,
                                    comment_description = @description,
                                    comment_date = @comment_date
                                WHERE comment_id = @id;
                ";

                SqlCommand command = new SqlCommand(query, date.Connection);
                command.Parameters.AddWithValue("@request_id", requestId);
                command.Parameters.AddWithValue("@specialist_id", specialistId);
                command.Parameters.AddWithValue("@description", commentText);
                command.Parameters.AddWithValue("@comment_date", commentDate);
                command.Parameters.AddWithValue("@id", data.indexComment);

                int result = command.ExecuteNonQuery();

                if (result > 0)
                {
                    MessageBox.Show("Комментарий обновлен!", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Ошибка при обновлении комментария.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при обновлении комментария: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                date.CloseConnection();
            }
        }
    }
}
