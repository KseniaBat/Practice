﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace statisticRequest
{
    public partial class Equipment1 : Form
    {
        public Equipment1()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text.Trim();
            string model = textBox2.Text.Trim();
            string serial = textBox3.Text.Trim();

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(model) || string.IsNullOrWhiteSpace(serial))
            {
                MessageBox.Show("Заполните все поля.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = @"INSERT INTO equipment (equipment_description, equipment_type, serial_number)
                         VALUES (@name, @model, @serial)";

                using (SqlCommand cmd = new SqlCommand(query, date.Connection))
                {
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@model", model);
                    cmd.Parameters.AddWithValue("@serial", serial);

                    date.OpenConnection();
                    int result = cmd.ExecuteNonQuery();
                    date.CloseConnection();

                    if (result > 0)
                    {
                        MessageBox.Show("Оборудование добавлено.", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close(); 
                    }
                    else
                    {
                        MessageBox.Show("Не удалось добавить оборудование.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                date.CloseConnection();
                MessageBox.Show("Ошибка при добавлении оборудования: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void labelName_Click(object sender, EventArgs e)
        {

        }
    }
}
