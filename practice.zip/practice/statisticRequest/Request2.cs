﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace statisticRequest
{
    public partial class Request2 : Form
    {
        public event EventHandler<StatusUpdatedEventArgs> StatusUpdated;
        public string oldStatus = "";
        public Request2()
        {
            InitializeComponent();
        }

        private void editRequest_Load(object sender, EventArgs e)
        {
            loadComboBox();
            loadComponent();
            oldStatus = comboBox4.Text;
        }

        public void loadComponent()
        {
            string query = @"SELECT 
                        a.request_id,
                        a.request_date,
                        c.full_name AS client_name,
                        e.equipment_description,
                        rt.type_name,
                        a.request_description,
                        s.status_name,
                        sp.full_name AS specialist_name
                    FROM 
                        request a
                    JOIN client c ON a.client_id = c.client_id
                    JOIN equipment e ON a.equipment_id = e.equipment_id
                    JOIN fault_type rt ON a.type_id = rt.fault_type_id
                    JOIN status s ON a.status_id = s.status_id
                    JOIN specialist sp ON a.specialist_id = sp.specialist_id
                    WHERE a.request_id = @id";

            using (SqlCommand cmd = new SqlCommand(query, date.Connection))
            {
                cmd.Parameters.AddWithValue("@id", data.indexRequest);

                date.OpenConnection();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        
                        maskedTextBox1.Text = Convert.ToDateTime(reader["request_date"]).ToString("dd.MM.yyyy");

                        comboBox1.SelectedItem = reader["client_name"].ToString();
                        comboBox2.SelectedItem = reader["equipment_description"].ToString();
                        comboBox3.SelectedItem = reader["type_name"].ToString();
                        comboBox4.SelectedItem = reader["status_name"].ToString();
                        comboBox5.SelectedItem = reader["specialist_name"].ToString();

                        richTextBox1.Text = reader["request_description"].ToString();
                    }
                }

                date.CloseConnection();
            }
        }

        public void loadComboBox()
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            comboBox5.Items.Clear();
            comboBox4.Items.Clear();
            comboBox3.Items.Clear();

            date.OpenConnection();

            string queryClient = "SELECT full_name FROM client";
            using (var cmd = new SqlCommand(queryClient, date.Connection))
            using (var rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                    comboBox1.Items.Add(rdr["full_name"].ToString());
            }

            string queryEquipment = "SELECT equipment_description FROM equipment";
            using (var cmd = new SqlCommand(queryEquipment, date.Connection))
            using (var rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                    comboBox2.Items.Add(rdr["equipment_description"].ToString());
            }

            string querySpecialist = "SELECT full_name FROM specialist";
            using (var cmd = new SqlCommand(querySpecialist, date.Connection))
            using (var rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                    comboBox5.Items.Add(rdr["full_name"].ToString());
            }

            string queryStatus = "SELECT status_name FROM status";
            using (var cmd = new SqlCommand(queryStatus, date.Connection))
            using (var rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                    comboBox4.Items.Add(rdr["status_name"].ToString());
            }

            string queryType = "SELECT type_name FROM fault_type";
            using (var cmd = new SqlCommand(queryType, date.Connection))
            using (var rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                    comboBox3.Items.Add(rdr["type_name"].ToString());
            }

            date.CloseConnection();
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (!DateTime.TryParse(maskedTextBox1.Text, out DateTime requestDate))
            {
                MessageBox.Show("Введите корректную дату.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (comboBox1.SelectedItem == null || comboBox2.SelectedItem == null ||
                comboBox3.SelectedItem == null || comboBox4.SelectedItem == null || comboBox5.SelectedItem == null)
            {
                MessageBox.Show("Заполните все поля.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string newStatus = comboBox4.Text;

            try
            {
                date.OpenConnection();

                int clientId = GetIdByValue("client", "client_id", "full_name", comboBox1.SelectedItem.ToString());
                int equipmentId = GetIdByValue("equipment", "equipment_id", "equipment_description", comboBox2.SelectedItem.ToString());
                int typeId = GetIdByValue("fault_type", "fault_type_id", "type_name", comboBox3.SelectedItem.ToString());
                int statusId = GetIdByValue("status", "status_id", "status_name", comboBox4.SelectedItem.ToString());
                int specialistId = GetIdByValue("specialist", "specialist_id", "full_name", comboBox5.SelectedItem.ToString());

                string updateQuery = @"UPDATE request 
                               SET 
                                   request_date = @date,
                                   client_id = @clientId,
                                   equipment_id = @equipmentId,
                                   type_id = @typeId,
                                   request_description = @description,
                                   status_id = @statusId,
                                   specialist_id = @specialistId
                               WHERE request_id = @requestId";

                using (SqlCommand cmd = new SqlCommand(updateQuery, date.Connection))
                {
                    cmd.Parameters.AddWithValue("@date", requestDate);
                    cmd.Parameters.AddWithValue("@clientId", clientId);
                    cmd.Parameters.AddWithValue("@equipmentId", equipmentId);
                    cmd.Parameters.AddWithValue("@typeId", typeId);
                    cmd.Parameters.AddWithValue("@description", richTextBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@statusId", statusId);
                    cmd.Parameters.AddWithValue("@specialistId", specialistId);
                    cmd.Parameters.AddWithValue("@requestId", data.indexRequest);

                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("Заявка обновлена!", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Не удалось обновить заявку.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    if (newStatus != oldStatus)
                    {
                        int requestId = data.indexRequest;
                        StatusUpdated?.Invoke(this, new StatusUpdatedEventArgs(requestId, newStatus));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                date.CloseConnection();
            }
        }

        private int GetIdByValue(string table, string idColumn, string nameColumn, string value)
        {
            string query = $"SELECT {idColumn} FROM {table} WHERE {nameColumn} = @value";

            using (SqlCommand cmd = new SqlCommand(query, date.Connection))
            {
                cmd.Parameters.AddWithValue("@value", value);
                object result = cmd.ExecuteScalar();
                if (result != null)
                    return Convert.ToInt32(result);
                else
                    throw new Exception($"Не найдено значение '{value}' в таблице {table}");
            }
        }

    }

    public class StatusUpdatedEventArgs : EventArgs
    {
        public int RequestId { get; }
        public string NewStatus { get; }

        public StatusUpdatedEventArgs(int requestId, string newStatus)
        {
            RequestId = requestId;
            NewStatus = newStatus;
        }
    }

}
