﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace statisticRequest
{
    public partial class Report2 : Form
    {
        public Report2()
        {
            InitializeComponent();
        }

        private void editReport_Load(object sender, EventArgs e)
        {
            loadComboBox();
            loadComponent();
        }

        public void loadComboBox()
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();

            date.OpenConnection();

            string queryRequest = "SELECT request_id FROM request";
            using (var cmd = new SqlCommand(queryRequest, date.Connection))
            using (var rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                    comboBox1.Items.Add(rdr["request_id"].ToString());
            }

            string querySpecialist = "SELECT full_name FROM specialist";
            using (var cmd = new SqlCommand(querySpecialist, date.Connection))
            using (var rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                    comboBox2.Items.Add(rdr["full_name"].ToString());
            }

            date.CloseConnection();
        }

        public void loadComponent()
        {
            string query = @"
                            SELECT 
                                r.report_id,
                                rq.request_id,
                                s.full_name,
                                r.work_description,
                                r.time_spent,
                                r.material_cost,
                                r.total_cost,
                                FORMAT(r.report_date, 'dd.MM.yyyy') AS report_date
                            FROM report r
                            JOIN request rq ON rq.request_id = r.request_id
                            JOIN specialist s ON r.specialist_id = s.specialist_id
                            WHERE report_id = @id;
                        ";

            using (SqlCommand cmd = new SqlCommand(query, date.Connection))
            {
                cmd.Parameters.AddWithValue("@id", data.indexReport);

                date.OpenConnection();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                      
                        maskedTextBox1.Text = Convert.ToDateTime(reader["report_date"]).ToString("dd.MM.yyyy");
                        comboBox1.SelectedItem = reader["request_id"].ToString();
                        comboBox2.SelectedItem = reader["full_name"].ToString();
                        textBox1.Text = reader["time_spent"].ToString();
                        textBox2.Text = reader["material_cost"].ToString();
                        textBox3.Text = reader["total_cost"].ToString();
                        richTextBox1.Text = reader["work_description"].ToString();
                    }
                }

                date.CloseConnection();
            }
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (!DateTime.TryParse(maskedTextBox1.Text, out DateTime reportDate))
            {
                MessageBox.Show("Введите корректную дату.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (comboBox1.SelectedItem == null ||
                comboBox2.SelectedItem == null ||
                string.IsNullOrWhiteSpace(richTextBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("Заполните все поля.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            CultureInfo culture = new CultureInfo("ru-RU");

            if (!float.TryParse(textBox1.Text, NumberStyles.Float, culture, out float timeSpent) ||
                !float.TryParse(textBox2.Text, NumberStyles.Float, culture, out float materialCost) ||
                !float.TryParse(textBox3.Text, NumberStyles.Float, culture, out float totalCost))
            {
                MessageBox.Show("Введите корректные числовые значения для времени, стоимости запчастей и стоимости работы.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int requestId = Convert.ToInt32(comboBox1.SelectedItem.ToString());
            int specialistId = 0;
            string workDescription = richTextBox1.Text.Trim();

            date.OpenConnection();

            string querySpecialistId = $@"SELECT specialist_id FROM specialist WHERE full_name = '{comboBox2.SelectedItem.ToString()}'";
            using (var cmd = new SqlCommand(querySpecialistId, date.Connection))
                specialistId = (int)cmd.ExecuteScalar();

            try
            {
                string query = @"
                                UPDATE report
                                SET
                                    request_id = @request_id,
                                    specialist_id = @specialist_id,
                                    work_description = @description,
                                    time_spent = @time_spent,
                                    material_cost = @material_cost,
                                    total_cost = @total_cost,
                                    report_date = @report_date
                                WHERE report_id = @id;
                ";

                SqlCommand command = new SqlCommand(query, date.Connection);
                command.Parameters.AddWithValue("@request_id", requestId);
                command.Parameters.AddWithValue("@specialist_id", specialistId);
                command.Parameters.AddWithValue("@description", workDescription);
                command.Parameters.AddWithValue("@time_spent", timeSpent);
                command.Parameters.AddWithValue("@material_cost", materialCost);
                command.Parameters.AddWithValue("@total_cost", totalCost);
                command.Parameters.AddWithValue("@report_date", reportDate);
                command.Parameters.AddWithValue("@id", data.indexReport);

                int result = command.ExecuteNonQuery();

                if (result > 0)
                {
                    MessageBox.Show("Отчет обновлен!", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Ошибка при обновлении отчета.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при обновлении отчета: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                date.CloseConnection();
            }
        }
    }
}
