﻿using System.Drawing;
using System.Windows.Forms.DataVisualization.Charting;

namespace statisticRequest
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartFaultStats;
        private System.Windows.Forms.ListView chartValuesListView;


        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label1 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.Button1 = new System.Windows.Forms.Button();
            this.Button4 = new System.Windows.Forms.Button();
            this.Button6 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.Button7 = new System.Windows.Forms.Button();
            this.Button9 = new System.Windows.Forms.Button();
            this.Button8 = new System.Windows.Forms.Button();
            this.Button10 = new System.Windows.Forms.Button();
            this.Button12 = new System.Windows.Forms.Button();
            this.Button11 = new System.Windows.Forms.Button();
            this.Button13 = new System.Windows.Forms.Button();
            this.Button15 = new System.Windows.Forms.Button();
            this.Button14 = new System.Windows.Forms.Button();
            this.Button16 = new System.Windows.Forms.Button();
            this.Button18 = new System.Windows.Forms.Button();
            this.Button17 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.statisticTabPage = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chartFaultStats = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartValuesListView = new System.Windows.Forms.ListView();
            this.kpiPanel = new System.Windows.Forms.Panel();
            this.completedCountLabel = new System.Windows.Forms.Label();
            this.avgTimeLabel = new System.Windows.Forms.Label();
            this.specialistTabPage = new System.Windows.Forms.TabPage();
            this.specialistPanel = new System.Windows.Forms.Panel();
            this.tablePanel4 = new System.Windows.Forms.Panel();
            this.specialistDGV = new System.Windows.Forms.DataGridView();
            this.searchPanel4 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.TextBox5 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ComboBox5 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.clientTabPage = new System.Windows.Forms.TabPage();
            this.clientPanel = new System.Windows.Forms.Panel();
            this.tablePanel3 = new System.Windows.Forms.Panel();
            this.clientDGV = new System.Windows.Forms.DataGridView();
            this.searchPanel3 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.TextBox4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ComboBox4 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.equipmentTabPage = new System.Windows.Forms.TabPage();
            this.equipmentPanel = new System.Windows.Forms.Panel();
            this.tablePanel2 = new System.Windows.Forms.Panel();
            this.equipmentDGV = new System.Windows.Forms.DataGridView();
            this.searchPanel2 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.TextBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ComboBox3 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.requestTabPage = new System.Windows.Forms.TabPage();
            this.tablePanel = new System.Windows.Forms.Panel();
            this.DataGridView = new System.Windows.Forms.DataGridView();
            this.searchPanel = new System.Windows.Forms.Panel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ComboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.commentTabPage = new System.Windows.Forms.TabPage();
            this.tabelPanel5 = new System.Windows.Forms.Panel();
            this.commentDGV = new System.Windows.Forms.DataGridView();
            this.searchPanel5 = new System.Windows.Forms.Panel();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.TextBox2 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ComboBox2 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.reportTabPage = new System.Windows.Forms.TabPage();
            this.tablePanel6 = new System.Windows.Forms.Panel();
            this.reportDGV = new System.Windows.Forms.DataGridView();
            this.searchPanel6 = new System.Windows.Forms.Panel();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.TextBox6 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.ComboBox6 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.statisticTabPage.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartFaultStats)).BeginInit();
            this.kpiPanel.SuspendLayout();
            this.specialistTabPage.SuspendLayout();
            this.specialistPanel.SuspendLayout();
            this.tablePanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.specialistDGV)).BeginInit();
            this.searchPanel4.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.clientTabPage.SuspendLayout();
            this.clientPanel.SuspendLayout();
            this.tablePanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clientDGV)).BeginInit();
            this.searchPanel3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.equipmentTabPage.SuspendLayout();
            this.equipmentPanel.SuspendLayout();
            this.tablePanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.equipmentDGV)).BeginInit();
            this.searchPanel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.requestTabPage.SuspendLayout();
            this.tablePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView)).BeginInit();
            this.searchPanel.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.commentTabPage.SuspendLayout();
            this.tabelPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.commentDGV)).BeginInit();
            this.searchPanel5.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.reportTabPage.SuspendLayout();
            this.tablePanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reportDGV)).BeginInit();
            this.searchPanel6.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoEllipsis = true;
            this.label1.BackColor = System.Drawing.Color.Gainsboro;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1284, 60);
            this.label1.TabIndex = 0;
            this.label1.Text = "Система учёта заявок на ремонт оборудования";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Button1
            // 
            this.Button1.BackColor = System.Drawing.Color.Silver;
            this.Button1.FlatAppearance.BorderSize = 0;
            this.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button1.ForeColor = System.Drawing.Color.Black;
            this.Button1.Location = new System.Drawing.Point(20, 25);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(90, 35);
            this.Button1.TabIndex = 1;
            this.Button1.Text = "Добавить";
            this.Button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button1, "Добавить заявку");
            this.Button1.UseVisualStyleBackColor = false;
            this.Button1.Click += new System.EventHandler(this.addRequestButton_Click);
            // 
            // Button4
            // 
            this.Button4.BackColor = System.Drawing.Color.Silver;
            this.Button4.FlatAppearance.BorderSize = 0;
            this.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button4.ForeColor = System.Drawing.Color.Black;
            this.Button4.Location = new System.Drawing.Point(16, 25);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(90, 35);
            this.Button4.TabIndex = 1;
            this.Button4.Text = "Добавить";
            this.Button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button4, "Добавить комментарий");
            this.Button4.UseVisualStyleBackColor = false;
            this.Button4.Click += new System.EventHandler(this.addCommentButton_Click);
            // 
            // Button6
            // 
            this.Button6.BackColor = System.Drawing.Color.Silver;
            this.Button6.FlatAppearance.BorderSize = 0;
            this.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button6.ForeColor = System.Drawing.Color.Black;
            this.Button6.Location = new System.Drawing.Point(208, 24);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(90, 35);
            this.Button6.TabIndex = 3;
            this.Button6.Text = "Удалить";
            this.Button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button6, "Удалить комментарий");
            this.Button6.UseVisualStyleBackColor = false;
            this.Button6.Click += new System.EventHandler(this.deleteCommentButton_Click);
            // 
            // Button5
            // 
            this.Button5.BackColor = System.Drawing.Color.Silver;
            this.Button5.FlatAppearance.BorderSize = 0;
            this.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button5.ForeColor = System.Drawing.Color.Black;
            this.Button5.Location = new System.Drawing.Point(112, 24);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(90, 35);
            this.Button5.TabIndex = 2;
            this.Button5.Text = "Изменить";
            this.Button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button5, "Редактировать комментарий");
            this.Button5.UseVisualStyleBackColor = false;
            this.Button5.Click += new System.EventHandler(this.editCommentButton_Click);
            // 
            // Button7
            // 
            this.Button7.BackColor = System.Drawing.Color.Silver;
            this.Button7.FlatAppearance.BorderSize = 0;
            this.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button7.ForeColor = System.Drawing.Color.Black;
            this.Button7.Location = new System.Drawing.Point(16, 25);
            this.Button7.Name = "Button7";
            this.Button7.Size = new System.Drawing.Size(90, 35);
            this.Button7.TabIndex = 1;
            this.Button7.Text = "Добавить";
            this.Button7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button7, "Добавить оборудование");
            this.Button7.UseVisualStyleBackColor = false;
            this.Button7.Click += new System.EventHandler(this.addEquipmentButton_Click);
            // 
            // Button9
            // 
            this.Button9.BackColor = System.Drawing.Color.Silver;
            this.Button9.FlatAppearance.BorderSize = 0;
            this.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button9.ForeColor = System.Drawing.Color.Black;
            this.Button9.Location = new System.Drawing.Point(208, 24);
            this.Button9.Name = "Button9";
            this.Button9.Size = new System.Drawing.Size(90, 35);
            this.Button9.TabIndex = 3;
            this.Button9.Text = "Удалить";
            this.Button9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button9, "Удалить оборудование");
            this.Button9.UseVisualStyleBackColor = false;
            this.Button9.Click += new System.EventHandler(this.deleteEquipmentButton_Click);
            // 
            // Button8
            // 
            this.Button8.BackColor = System.Drawing.Color.Silver;
            this.Button8.FlatAppearance.BorderSize = 0;
            this.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button8.ForeColor = System.Drawing.Color.Black;
            this.Button8.Location = new System.Drawing.Point(112, 24);
            this.Button8.Name = "Button8";
            this.Button8.Size = new System.Drawing.Size(90, 35);
            this.Button8.TabIndex = 2;
            this.Button8.Text = "Изменить";
            this.Button8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button8, "Редактировать оборудование");
            this.Button8.UseVisualStyleBackColor = false;
            this.Button8.Click += new System.EventHandler(this.editEquipmentButton_Click);
            // 
            // Button10
            // 
            this.Button10.BackColor = System.Drawing.Color.Silver;
            this.Button10.FlatAppearance.BorderSize = 0;
            this.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button10.ForeColor = System.Drawing.Color.Black;
            this.Button10.Location = new System.Drawing.Point(16, 25);
            this.Button10.Name = "Button10";
            this.Button10.Size = new System.Drawing.Size(90, 35);
            this.Button10.TabIndex = 1;
            this.Button10.Text = "Добавить";
            this.Button10.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button10, "Добавить клиента");
            this.Button10.UseVisualStyleBackColor = false;
            this.Button10.Click += new System.EventHandler(this.addClientButton_Click);
            // 
            // Button12
            // 
            this.Button12.BackColor = System.Drawing.Color.Silver;
            this.Button12.FlatAppearance.BorderSize = 0;
            this.Button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button12.ForeColor = System.Drawing.Color.Black;
            this.Button12.Location = new System.Drawing.Point(208, 24);
            this.Button12.Name = "Button12";
            this.Button12.Size = new System.Drawing.Size(90, 35);
            this.Button12.TabIndex = 3;
            this.Button12.Text = "Удалить";
            this.Button12.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button12, "Удалить клиента");
            this.Button12.UseVisualStyleBackColor = false;
            this.Button12.Click += new System.EventHandler(this.deleteClientButton_Click);
            // 
            // Button11
            // 
            this.Button11.BackColor = System.Drawing.Color.Silver;
            this.Button11.FlatAppearance.BorderSize = 0;
            this.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button11.ForeColor = System.Drawing.Color.Black;
            this.Button11.Location = new System.Drawing.Point(112, 24);
            this.Button11.Name = "Button11";
            this.Button11.Size = new System.Drawing.Size(90, 35);
            this.Button11.TabIndex = 2;
            this.Button11.Text = "Изменить";
            this.Button11.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button11, "Редактировать клиента");
            this.Button11.UseVisualStyleBackColor = false;
            this.Button11.Click += new System.EventHandler(this.editClientButton_Click);
            // 
            // Button13
            // 
            this.Button13.BackColor = System.Drawing.Color.Silver;
            this.Button13.FlatAppearance.BorderSize = 0;
            this.Button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button13.ForeColor = System.Drawing.Color.Black;
            this.Button13.Location = new System.Drawing.Point(16, 25);
            this.Button13.Name = "Button13";
            this.Button13.Size = new System.Drawing.Size(90, 35);
            this.Button13.TabIndex = 1;
            this.Button13.Text = "Добавить";
            this.Button13.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button13, "Добавить специалиста");
            this.Button13.UseVisualStyleBackColor = false;
            this.Button13.Click += new System.EventHandler(this.addSpecialistButton_Click);
            // 
            // Button15
            // 
            this.Button15.BackColor = System.Drawing.Color.Silver;
            this.Button15.FlatAppearance.BorderSize = 0;
            this.Button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button15.ForeColor = System.Drawing.Color.Black;
            this.Button15.Location = new System.Drawing.Point(208, 24);
            this.Button15.Name = "Button15";
            this.Button15.Size = new System.Drawing.Size(90, 35);
            this.Button15.TabIndex = 3;
            this.Button15.Text = "Удалить";
            this.Button15.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button15, "Удалить специалиста");
            this.Button15.UseVisualStyleBackColor = false;
            this.Button15.Click += new System.EventHandler(this.deleteSpecialistButton_Click);
            // 
            // Button14
            // 
            this.Button14.BackColor = System.Drawing.Color.Silver;
            this.Button14.FlatAppearance.BorderSize = 0;
            this.Button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button14.ForeColor = System.Drawing.Color.Black;
            this.Button14.Location = new System.Drawing.Point(112, 24);
            this.Button14.Name = "Button14";
            this.Button14.Size = new System.Drawing.Size(90, 35);
            this.Button14.TabIndex = 2;
            this.Button14.Text = "Изменить";
            this.Button14.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button14, "Редактировать специалиста");
            this.Button14.UseVisualStyleBackColor = false;
            this.Button14.Click += new System.EventHandler(this.editSpecialistButton_Click);
            // 
            // Button16
            // 
            this.Button16.BackColor = System.Drawing.Color.Silver;
            this.Button16.FlatAppearance.BorderSize = 0;
            this.Button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button16.ForeColor = System.Drawing.Color.Black;
            this.Button16.Location = new System.Drawing.Point(16, 25);
            this.Button16.Name = "Button16";
            this.Button16.Size = new System.Drawing.Size(90, 35);
            this.Button16.TabIndex = 1;
            this.Button16.Text = "Добавить";
            this.Button16.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button16, "Добавить отчет");
            this.Button16.UseVisualStyleBackColor = false;
            this.Button16.Click += new System.EventHandler(this.addReportButton_Click);
            // 
            // Button18
            // 
            this.Button18.BackColor = System.Drawing.Color.Silver;
            this.Button18.FlatAppearance.BorderSize = 0;
            this.Button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button18.ForeColor = System.Drawing.Color.Black;
            this.Button18.Location = new System.Drawing.Point(208, 24);
            this.Button18.Name = "Button18";
            this.Button18.Size = new System.Drawing.Size(90, 35);
            this.Button18.TabIndex = 3;
            this.Button18.Text = "Удалить";
            this.Button18.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button18, "Удалить отчет");
            this.Button18.UseVisualStyleBackColor = false;
            this.Button18.Click += new System.EventHandler(this.deleteReportButton_Click);
            // 
            // Button17
            // 
            this.Button17.BackColor = System.Drawing.Color.Silver;
            this.Button17.FlatAppearance.BorderSize = 0;
            this.Button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button17.ForeColor = System.Drawing.Color.Black;
            this.Button17.Location = new System.Drawing.Point(112, 24);
            this.Button17.Name = "Button17";
            this.Button17.Size = new System.Drawing.Size(90, 35);
            this.Button17.TabIndex = 2;
            this.Button17.Text = "Изменить";
            this.Button17.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.Button17, "Редактировать отчет");
            this.Button17.UseVisualStyleBackColor = false;
            this.Button17.Click += new System.EventHandler(this.editReportButton_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Silver;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(236, 25);
            this.button3.Name = "button3";
            this.button3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button3.Size = new System.Drawing.Size(90, 35);
            this.button3.TabIndex = 5;
            this.button3.Text = "Удалить";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.button3, "Удалить заявку");
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button20_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Silver;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(125, 25);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(90, 35);
            this.button2.TabIndex = 6;
            this.button2.Text = "Изменить";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.button2, "Редактировать заявку");
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button21_Click);
            // 
            // statisticTabPage
            // 
            this.statisticTabPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(46)))));
            this.statisticTabPage.Controls.Add(this.panel4);
            this.statisticTabPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.statisticTabPage.Location = new System.Drawing.Point(4, 24);
            this.statisticTabPage.Name = "statisticTabPage";
            this.statisticTabPage.Size = new System.Drawing.Size(1276, 673);
            this.statisticTabPage.TabIndex = 3;
            this.statisticTabPage.Text = "Статистика";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.panel4.Controls.Add(this.panel1);
            this.panel4.Controls.Add(this.kpiPanel);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1276, 673);
            this.panel4.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.chartFaultStats);
            this.panel1.Controls.Add(this.chartValuesListView);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 100);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1276, 573);
            this.panel1.TabIndex = 3;
            // 
            // chartFaultStats
            // 
            this.chartFaultStats.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.LeftRight;
            this.chartFaultStats.BackHatchStyle = System.Windows.Forms.DataVisualization.Charting.ChartHatchStyle.DashedDownwardDiagonal;
            this.chartFaultStats.BorderlineColor = System.Drawing.Color.Transparent;
            this.chartFaultStats.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            chartArea1.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(46)))));
            chartArea1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(46)))));
            chartArea1.Name = "ChartArea1";
            chartArea1.ShadowColor = System.Drawing.Color.Transparent;
            this.chartFaultStats.ChartAreas.Add(chartArea1);
            this.chartFaultStats.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartFaultStats.Location = new System.Drawing.Point(0, 0);
            this.chartFaultStats.Name = "chartFaultStats";
            this.chartFaultStats.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Berry;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            series1.LabelForeColor = System.Drawing.Color.White;
            series1.Name = "Типы";
            this.chartFaultStats.Series.Add(series1);
            this.chartFaultStats.Size = new System.Drawing.Size(851, 573);
            this.chartFaultStats.TabIndex = 0;
            // 
            // chartValuesListView
            // 
            this.chartValuesListView.BackColor = System.Drawing.Color.White;
            this.chartValuesListView.Dock = System.Windows.Forms.DockStyle.Right;
            this.chartValuesListView.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.chartValuesListView.ForeColor = System.Drawing.Color.Black;
            this.chartValuesListView.HideSelection = false;
            this.chartValuesListView.Location = new System.Drawing.Point(851, 0);
            this.chartValuesListView.Name = "chartValuesListView";
            this.chartValuesListView.Size = new System.Drawing.Size(425, 573);
            this.chartValuesListView.TabIndex = 1;
            this.chartValuesListView.UseCompatibleStateImageBehavior = false;
            this.chartValuesListView.View = System.Windows.Forms.View.Details;
            // 
            // kpiPanel
            // 
            this.kpiPanel.Controls.Add(this.completedCountLabel);
            this.kpiPanel.Controls.Add(this.avgTimeLabel);
            this.kpiPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.kpiPanel.Location = new System.Drawing.Point(0, 0);
            this.kpiPanel.Name = "kpiPanel";
            this.kpiPanel.Size = new System.Drawing.Size(1276, 100);
            this.kpiPanel.TabIndex = 2;
            // 
            // completedCountLabel
            // 
            this.completedCountLabel.BackColor = System.Drawing.Color.White;
            this.completedCountLabel.Dock = System.Windows.Forms.DockStyle.Top;
            this.completedCountLabel.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.completedCountLabel.ForeColor = System.Drawing.Color.Black;
            this.completedCountLabel.Location = new System.Drawing.Point(0, 0);
            this.completedCountLabel.Name = "completedCountLabel";
            this.completedCountLabel.Size = new System.Drawing.Size(1276, 37);
            this.completedCountLabel.TabIndex = 0;
            this.completedCountLabel.Text = "Выполненные заявки: 0";
            this.completedCountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // avgTimeLabel
            // 
            this.avgTimeLabel.BackColor = System.Drawing.Color.White;
            this.avgTimeLabel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.avgTimeLabel.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.avgTimeLabel.ForeColor = System.Drawing.Color.Black;
            this.avgTimeLabel.Location = new System.Drawing.Point(0, 37);
            this.avgTimeLabel.Name = "avgTimeLabel";
            this.avgTimeLabel.Size = new System.Drawing.Size(1276, 63);
            this.avgTimeLabel.TabIndex = 1;
            this.avgTimeLabel.Text = "Среднее время выполнения заявок: 0 ч.";
            this.avgTimeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // specialistTabPage
            // 
            this.specialistTabPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(46)))));
            this.specialistTabPage.Controls.Add(this.specialistPanel);
            this.specialistTabPage.Location = new System.Drawing.Point(4, 24);
            this.specialistTabPage.Name = "specialistTabPage";
            this.specialistTabPage.Size = new System.Drawing.Size(1276, 673);
            this.specialistTabPage.TabIndex = 5;
            this.specialistTabPage.Text = "Специалисты";
            // 
            // specialistPanel
            // 
            this.specialistPanel.Controls.Add(this.tablePanel4);
            this.specialistPanel.Controls.Add(this.searchPanel4);
            this.specialistPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.specialistPanel.Location = new System.Drawing.Point(0, 0);
            this.specialistPanel.Name = "specialistPanel";
            this.specialistPanel.Size = new System.Drawing.Size(1276, 673);
            this.specialistPanel.TabIndex = 4;
            // 
            // tablePanel4
            // 
            this.tablePanel4.Controls.Add(this.specialistDGV);
            this.tablePanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tablePanel4.Location = new System.Drawing.Point(0, 72);
            this.tablePanel4.Name = "tablePanel4";
            this.tablePanel4.Size = new System.Drawing.Size(1276, 601);
            this.tablePanel4.TabIndex = 2;
            // 
            // specialistDGV
            // 
            this.specialistDGV.AllowUserToAddRows = false;
            this.specialistDGV.AllowUserToDeleteRows = false;
            this.specialistDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.specialistDGV.BackgroundColor = System.Drawing.Color.White;
            this.specialistDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.specialistDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.specialistDGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.specialistDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(77)))));
            this.specialistDGV.Location = new System.Drawing.Point(0, 0);
            this.specialistDGV.MultiSelect = false;
            this.specialistDGV.Name = "specialistDGV";
            this.specialistDGV.ReadOnly = true;
            this.specialistDGV.RowHeadersWidth = 62;
            this.specialistDGV.RowTemplate.Height = 28;
            this.specialistDGV.Size = new System.Drawing.Size(1276, 601);
            this.specialistDGV.TabIndex = 0;
            this.specialistDGV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.specialistDGV_CellClick);
            // 
            // searchPanel4
            // 
            this.searchPanel4.BackColor = System.Drawing.Color.White;
            this.searchPanel4.Controls.Add(this.groupBox4);
            this.searchPanel4.Controls.Add(this.groupBox8);
            this.searchPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.searchPanel4.ForeColor = System.Drawing.Color.Black;
            this.searchPanel4.Location = new System.Drawing.Point(0, 0);
            this.searchPanel4.Name = "searchPanel4";
            this.searchPanel4.Size = new System.Drawing.Size(1276, 72);
            this.searchPanel4.TabIndex = 1;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.White;
            this.groupBox4.Controls.Add(this.Button13);
            this.groupBox4.Controls.Add(this.Button15);
            this.groupBox4.Controls.Add(this.Button14);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox4.ForeColor = System.Drawing.Color.Black;
            this.groupBox4.Location = new System.Drawing.Point(654, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(622, 72);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Управление специалистами";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.TextBox5);
            this.groupBox8.Controls.Add(this.label8);
            this.groupBox8.Controls.Add(this.ComboBox5);
            this.groupBox8.Controls.Add(this.label9);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox8.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox8.ForeColor = System.Drawing.Color.Black;
            this.groupBox8.Location = new System.Drawing.Point(0, 0);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(622, 72);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Поиск";
            // 
            // TextBox5
            // 
            this.TextBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TextBox5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBox5.ForeColor = System.Drawing.Color.Black;
            this.TextBox5.Location = new System.Drawing.Point(368, 29);
            this.TextBox5.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.TextBox5.Name = "TextBox5";
            this.TextBox5.Size = new System.Drawing.Size(232, 23);
            this.TextBox5.TabIndex = 4;
            this.TextBox5.TextChanged += new System.EventHandler(this.searchSpecialistTextBox_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(297, 32);
            this.label8.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 19);
            this.label8.TabIndex = 3;
            this.label8.Text = "Значение:";
            // 
            // ComboBox5
            // 
            this.ComboBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ComboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ComboBox5.ForeColor = System.Drawing.Color.Black;
            this.ComboBox5.FormattingEnabled = true;
            this.ComboBox5.Items.AddRange(new object[] {
            "По номеру специалиста",
            "По ФИО",
            "По электронной почте",
            "По номеру телефона"});
            this.ComboBox5.Location = new System.Drawing.Point(111, 29);
            this.ComboBox5.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.ComboBox5.Name = "ComboBox5";
            this.ComboBox5.Size = new System.Drawing.Size(166, 23);
            this.ComboBox5.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(21, 32);
            this.label9.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 19);
            this.label9.TabIndex = 2;
            this.label9.Text = "Фильтрация:";
            // 
            // clientTabPage
            // 
            this.clientTabPage.BackColor = System.Drawing.Color.White;
            this.clientTabPage.Controls.Add(this.clientPanel);
            this.clientTabPage.Location = new System.Drawing.Point(4, 24);
            this.clientTabPage.Name = "clientTabPage";
            this.clientTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.clientTabPage.Size = new System.Drawing.Size(1276, 673);
            this.clientTabPage.TabIndex = 4;
            this.clientTabPage.Text = "Клиенты";
            // 
            // clientPanel
            // 
            this.clientPanel.Controls.Add(this.tablePanel3);
            this.clientPanel.Controls.Add(this.searchPanel3);
            this.clientPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.clientPanel.Location = new System.Drawing.Point(3, 3);
            this.clientPanel.Name = "clientPanel";
            this.clientPanel.Size = new System.Drawing.Size(1270, 667);
            this.clientPanel.TabIndex = 3;
            // 
            // tablePanel3
            // 
            this.tablePanel3.Controls.Add(this.clientDGV);
            this.tablePanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tablePanel3.Location = new System.Drawing.Point(0, 72);
            this.tablePanel3.Name = "tablePanel3";
            this.tablePanel3.Size = new System.Drawing.Size(1270, 595);
            this.tablePanel3.TabIndex = 2;
            // 
            // clientDGV
            // 
            this.clientDGV.AllowUserToAddRows = false;
            this.clientDGV.AllowUserToDeleteRows = false;
            this.clientDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.clientDGV.BackgroundColor = System.Drawing.Color.White;
            this.clientDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clientDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.clientDGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.clientDGV.GridColor = System.Drawing.Color.White;
            this.clientDGV.Location = new System.Drawing.Point(0, 0);
            this.clientDGV.MultiSelect = false;
            this.clientDGV.Name = "clientDGV";
            this.clientDGV.ReadOnly = true;
            this.clientDGV.RowHeadersWidth = 62;
            this.clientDGV.RowTemplate.Height = 28;
            this.clientDGV.Size = new System.Drawing.Size(1270, 595);
            this.clientDGV.TabIndex = 0;
            this.clientDGV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.clientDGV_CellClick);
            // 
            // searchPanel3
            // 
            this.searchPanel3.BackColor = System.Drawing.Color.White;
            this.searchPanel3.Controls.Add(this.groupBox3);
            this.searchPanel3.Controls.Add(this.groupBox7);
            this.searchPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.searchPanel3.Location = new System.Drawing.Point(0, 0);
            this.searchPanel3.Name = "searchPanel3";
            this.searchPanel3.Size = new System.Drawing.Size(1270, 72);
            this.searchPanel3.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.White;
            this.groupBox3.Controls.Add(this.Button10);
            this.groupBox3.Controls.Add(this.Button12);
            this.groupBox3.Controls.Add(this.Button11);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox3.ForeColor = System.Drawing.Color.Black;
            this.groupBox3.Location = new System.Drawing.Point(648, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(622, 72);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Управление клиентами";
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.White;
            this.groupBox7.Controls.Add(this.TextBox4);
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Controls.Add(this.ComboBox4);
            this.groupBox7.Controls.Add(this.label7);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox7.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox7.ForeColor = System.Drawing.Color.Black;
            this.groupBox7.Location = new System.Drawing.Point(0, 0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(622, 72);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Поиск";
            // 
            // TextBox4
            // 
            this.TextBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TextBox4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBox4.ForeColor = System.Drawing.Color.Black;
            this.TextBox4.Location = new System.Drawing.Point(368, 29);
            this.TextBox4.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.TextBox4.Name = "TextBox4";
            this.TextBox4.Size = new System.Drawing.Size(232, 23);
            this.TextBox4.TabIndex = 4;
            this.TextBox4.TextChanged += new System.EventHandler(this.searchClientTextBox_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(297, 32);
            this.label6.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 19);
            this.label6.TabIndex = 3;
            this.label6.Text = "Значение:";
            // 
            // ComboBox4
            // 
            this.ComboBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ComboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ComboBox4.ForeColor = System.Drawing.Color.Black;
            this.ComboBox4.FormattingEnabled = true;
            this.ComboBox4.Items.AddRange(new object[] {
            "По номеру клиента",
            "По ФИО",
            "По электронной почте",
            "По номеру телефона"});
            this.ComboBox4.Location = new System.Drawing.Point(111, 29);
            this.ComboBox4.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.ComboBox4.Name = "ComboBox4";
            this.ComboBox4.Size = new System.Drawing.Size(166, 23);
            this.ComboBox4.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(21, 32);
            this.label7.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 19);
            this.label7.TabIndex = 2;
            this.label7.Text = "Фильтрация:";
            // 
            // equipmentTabPage
            // 
            this.equipmentTabPage.BackColor = System.Drawing.Color.White;
            this.equipmentTabPage.Controls.Add(this.equipmentPanel);
            this.equipmentTabPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.equipmentTabPage.Location = new System.Drawing.Point(4, 24);
            this.equipmentTabPage.Name = "equipmentTabPage";
            this.equipmentTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.equipmentTabPage.Size = new System.Drawing.Size(1276, 673);
            this.equipmentTabPage.TabIndex = 1;
            this.equipmentTabPage.Text = "Оборудование";
            // 
            // equipmentPanel
            // 
            this.equipmentPanel.BackColor = System.Drawing.Color.White;
            this.equipmentPanel.Controls.Add(this.tablePanel2);
            this.equipmentPanel.Controls.Add(this.searchPanel2);
            this.equipmentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.equipmentPanel.Location = new System.Drawing.Point(3, 3);
            this.equipmentPanel.Name = "equipmentPanel";
            this.equipmentPanel.Size = new System.Drawing.Size(1270, 667);
            this.equipmentPanel.TabIndex = 2;
            // 
            // tablePanel2
            // 
            this.tablePanel2.BackColor = System.Drawing.Color.White;
            this.tablePanel2.Controls.Add(this.equipmentDGV);
            this.tablePanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tablePanel2.Location = new System.Drawing.Point(0, 72);
            this.tablePanel2.Name = "tablePanel2";
            this.tablePanel2.Size = new System.Drawing.Size(1270, 595);
            this.tablePanel2.TabIndex = 2;
            // 
            // equipmentDGV
            // 
            this.equipmentDGV.AllowUserToAddRows = false;
            this.equipmentDGV.AllowUserToDeleteRows = false;
            this.equipmentDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.equipmentDGV.BackgroundColor = System.Drawing.Color.White;
            this.equipmentDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.equipmentDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.equipmentDGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.equipmentDGV.GridColor = System.Drawing.Color.White;
            this.equipmentDGV.Location = new System.Drawing.Point(0, 0);
            this.equipmentDGV.MultiSelect = false;
            this.equipmentDGV.Name = "equipmentDGV";
            this.equipmentDGV.ReadOnly = true;
            this.equipmentDGV.RowHeadersWidth = 62;
            this.equipmentDGV.RowTemplate.Height = 28;
            this.equipmentDGV.Size = new System.Drawing.Size(1270, 595);
            this.equipmentDGV.TabIndex = 0;
            this.equipmentDGV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.equipmentDGV_CellClick);
            // 
            // searchPanel2
            // 
            this.searchPanel2.BackColor = System.Drawing.Color.White;
            this.searchPanel2.Controls.Add(this.groupBox2);
            this.searchPanel2.Controls.Add(this.groupBox6);
            this.searchPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.searchPanel2.Location = new System.Drawing.Point(0, 0);
            this.searchPanel2.Name = "searchPanel2";
            this.searchPanel2.Size = new System.Drawing.Size(1270, 72);
            this.searchPanel2.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.Button7);
            this.groupBox2.Controls.Add(this.Button9);
            this.groupBox2.Controls.Add(this.Button8);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(648, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(622, 72);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Управление оборудованием";
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.White;
            this.groupBox6.Controls.Add(this.TextBox3);
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Controls.Add(this.ComboBox3);
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox6.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox6.ForeColor = System.Drawing.Color.Black;
            this.groupBox6.Location = new System.Drawing.Point(0, 0);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(622, 72);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Поиск";
            // 
            // TextBox3
            // 
            this.TextBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TextBox3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBox3.ForeColor = System.Drawing.Color.Black;
            this.TextBox3.Location = new System.Drawing.Point(368, 29);
            this.TextBox3.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.TextBox3.Name = "TextBox3";
            this.TextBox3.Size = new System.Drawing.Size(232, 23);
            this.TextBox3.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(297, 32);
            this.label4.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Значение:";
            // 
            // ComboBox3
            // 
            this.ComboBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ComboBox3.ForeColor = System.Drawing.Color.Black;
            this.ComboBox3.FormattingEnabled = true;
            this.ComboBox3.Items.AddRange(new object[] {
            "По номеру оборудования",
            "По серийному номеру",
            "По типу оборудования",
            "По названию"});
            this.ComboBox3.Location = new System.Drawing.Point(111, 29);
            this.ComboBox3.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.ComboBox3.Name = "ComboBox3";
            this.ComboBox3.Size = new System.Drawing.Size(166, 23);
            this.ComboBox3.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(21, 32);
            this.label5.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 19);
            this.label5.TabIndex = 2;
            this.label5.Text = "Фильтрация:";
            // 
            // requestTabPage
            // 
            this.requestTabPage.BackColor = System.Drawing.Color.White;
            this.requestTabPage.Controls.Add(this.tablePanel);
            this.requestTabPage.Controls.Add(this.searchPanel);
            this.requestTabPage.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.requestTabPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.requestTabPage.Location = new System.Drawing.Point(4, 24);
            this.requestTabPage.Name = "requestTabPage";
            this.requestTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.requestTabPage.Size = new System.Drawing.Size(1276, 673);
            this.requestTabPage.TabIndex = 0;
            this.requestTabPage.Text = "Заявки";
            // 
            // tablePanel
            // 
            this.tablePanel.Controls.Add(this.DataGridView);
            this.tablePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tablePanel.Location = new System.Drawing.Point(3, 75);
            this.tablePanel.Name = "tablePanel";
            this.tablePanel.Size = new System.Drawing.Size(1270, 595);
            this.tablePanel.TabIndex = 1;
            // 
            // DataGridView
            // 
            this.DataGridView.AllowUserToAddRows = false;
            this.DataGridView.AllowUserToDeleteRows = false;
            this.DataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridView.BackgroundColor = System.Drawing.Color.White;
            this.DataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DataGridView.GridColor = System.Drawing.Color.White;
            this.DataGridView.Location = new System.Drawing.Point(0, 0);
            this.DataGridView.MultiSelect = false;
            this.DataGridView.Name = "DataGridView";
            this.DataGridView.ReadOnly = true;
            this.DataGridView.RowHeadersWidth = 62;
            this.DataGridView.RowTemplate.Height = 28;
            this.DataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.DataGridView.Size = new System.Drawing.Size(1270, 595);
            this.DataGridView.TabIndex = 2;
            this.DataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.requestDGV_CellClick);
            // 
            // searchPanel
            // 
            this.searchPanel.BackColor = System.Drawing.Color.White;
            this.searchPanel.Controls.Add(this.groupBox5);
            this.searchPanel.Controls.Add(this.groupBox1);
            this.searchPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.searchPanel.Location = new System.Drawing.Point(3, 3);
            this.searchPanel.Name = "searchPanel";
            this.searchPanel.Size = new System.Drawing.Size(1270, 72);
            this.searchPanel.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.White;
            this.groupBox5.Controls.Add(this.button2);
            this.groupBox5.Controls.Add(this.button3);
            this.groupBox5.Controls.Add(this.Button1);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox5.ForeColor = System.Drawing.Color.Black;
            this.groupBox5.Location = new System.Drawing.Point(648, 0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(622, 72);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Управление заявками";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.TextBox1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.ComboBox1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(622, 72);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Поиск";
            // 
            // TextBox1
            // 
            this.TextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TextBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBox1.ForeColor = System.Drawing.Color.Black;
            this.TextBox1.Location = new System.Drawing.Point(403, 32);
            this.TextBox1.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(232, 23);
            this.TextBox1.TabIndex = 4;
            this.TextBox1.TextChanged += new System.EventHandler(this.searchTextBox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(319, 40);
            this.label3.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 19);
            this.label3.TabIndex = 3;
            this.label3.Text = "Значение:";
            // 
            // ComboBox1
            // 
            this.ComboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ComboBox1.ForeColor = System.Drawing.Color.Black;
            this.ComboBox1.FormattingEnabled = true;
            this.ComboBox1.Items.AddRange(new object[] {
            "По номеру заявки",
            "По клиенту",
            "По оборудованию",
            "По статусу"});
            this.ComboBox1.Location = new System.Drawing.Point(111, 29);
            this.ComboBox1.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.ComboBox1.Name = "ComboBox1";
            this.ComboBox1.Size = new System.Drawing.Size(166, 23);
            this.ComboBox1.TabIndex = 1;
   //         this.ComboBox1.SelectedIndexChanged += new System.EventHandler(this.ComboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(21, 32);
            this.label2.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Фильтрация:";
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.requestTabPage);
            this.tabControl.Controls.Add(this.commentTabPage);
            this.tabControl.Controls.Add(this.equipmentTabPage);
            this.tabControl.Controls.Add(this.clientTabPage);
            this.tabControl.Controls.Add(this.specialistTabPage);
            this.tabControl.Controls.Add(this.reportTabPage);
            this.tabControl.Controls.Add(this.statisticTabPage);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControl.Location = new System.Drawing.Point(0, 60);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1284, 701);
            this.tabControl.TabIndex = 1;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // commentTabPage
            // 
            this.commentTabPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(46)))));
            this.commentTabPage.Controls.Add(this.tabelPanel5);
            this.commentTabPage.Controls.Add(this.searchPanel5);
            this.commentTabPage.Location = new System.Drawing.Point(4, 24);
            this.commentTabPage.Name = "commentTabPage";
            this.commentTabPage.Size = new System.Drawing.Size(1276, 673);
            this.commentTabPage.TabIndex = 6;
            this.commentTabPage.Text = "Комментарии";
            // 
            // tabelPanel5
            // 
            this.tabelPanel5.Controls.Add(this.commentDGV);
            this.tabelPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabelPanel5.Location = new System.Drawing.Point(0, 72);
            this.tabelPanel5.Name = "tabelPanel5";
            this.tabelPanel5.Size = new System.Drawing.Size(1276, 601);
            this.tabelPanel5.TabIndex = 2;
            // 
            // commentDGV
            // 
            this.commentDGV.AllowUserToAddRows = false;
            this.commentDGV.AllowUserToDeleteRows = false;
            this.commentDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.commentDGV.BackgroundColor = System.Drawing.Color.White;
            this.commentDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.commentDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.commentDGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.commentDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(77)))));
            this.commentDGV.Location = new System.Drawing.Point(0, 0);
            this.commentDGV.MultiSelect = false;
            this.commentDGV.Name = "commentDGV";
            this.commentDGV.ReadOnly = true;
            this.commentDGV.RowHeadersWidth = 62;
            this.commentDGV.RowTemplate.Height = 28;
            this.commentDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.commentDGV.Size = new System.Drawing.Size(1276, 601);
            this.commentDGV.TabIndex = 0;
            this.commentDGV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.commentDGV_CellClick);
            // 
            // searchPanel5
            // 
            this.searchPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.searchPanel5.Controls.Add(this.groupBox9);
            this.searchPanel5.Controls.Add(this.groupBox10);
            this.searchPanel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.searchPanel5.Location = new System.Drawing.Point(0, 0);
            this.searchPanel5.Name = "searchPanel5";
            this.searchPanel5.Size = new System.Drawing.Size(1276, 72);
            this.searchPanel5.TabIndex = 1;
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.White;
            this.groupBox9.Controls.Add(this.Button4);
            this.groupBox9.Controls.Add(this.Button6);
            this.groupBox9.Controls.Add(this.Button5);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox9.ForeColor = System.Drawing.Color.Black;
            this.groupBox9.Location = new System.Drawing.Point(654, 0);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(622, 72);
            this.groupBox9.TabIndex = 2;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Управление комментариями";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.TextBox2);
            this.groupBox10.Controls.Add(this.label10);
            this.groupBox10.Controls.Add(this.ComboBox2);
            this.groupBox10.Controls.Add(this.label11);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox10.ForeColor = System.Drawing.Color.Black;
            this.groupBox10.Location = new System.Drawing.Point(0, 0);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(622, 72);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Поиск";
            // 
            // TextBox2
            // 
            this.TextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TextBox2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBox2.ForeColor = System.Drawing.Color.White;
            this.TextBox2.Location = new System.Drawing.Point(409, 32);
            this.TextBox2.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.TextBox2.Name = "TextBox2";
            this.TextBox2.Size = new System.Drawing.Size(232, 23);
            this.TextBox2.TabIndex = 4;
            this.TextBox2.TextChanged += new System.EventHandler(this.searchCommentTextBox_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(297, 32);
            this.label10.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 19);
            this.label10.TabIndex = 3;
            this.label10.Text = "Значение:";
            // 
            // ComboBox2
            // 
            this.ComboBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ComboBox2.ForeColor = System.Drawing.Color.White;
            this.ComboBox2.FormattingEnabled = true;
            this.ComboBox2.Items.AddRange(new object[] {
            "По номеру комментария",
            "По номеру заявки",
            "По ФИО"});
            this.ComboBox2.Location = new System.Drawing.Point(111, 29);
            this.ComboBox2.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.ComboBox2.Name = "ComboBox2";
            this.ComboBox2.Size = new System.Drawing.Size(166, 23);
            this.ComboBox2.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(21, 32);
            this.label11.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 19);
            this.label11.TabIndex = 2;
            this.label11.Text = "Фильтрация:";
            // 
            // reportTabPage
            // 
            this.reportTabPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(46)))));
            this.reportTabPage.Controls.Add(this.tablePanel6);
            this.reportTabPage.Controls.Add(this.searchPanel6);
            this.reportTabPage.Location = new System.Drawing.Point(4, 24);
            this.reportTabPage.Name = "reportTabPage";
            this.reportTabPage.Size = new System.Drawing.Size(1276, 673);
            this.reportTabPage.TabIndex = 7;
            this.reportTabPage.Text = "Отчеты";
            // 
            // tablePanel6
            // 
            this.tablePanel6.Controls.Add(this.reportDGV);
            this.tablePanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tablePanel6.Location = new System.Drawing.Point(0, 72);
            this.tablePanel6.Name = "tablePanel6";
            this.tablePanel6.Size = new System.Drawing.Size(1276, 601);
            this.tablePanel6.TabIndex = 2;
            // 
            // reportDGV
            // 
            this.reportDGV.AllowUserToAddRows = false;
            this.reportDGV.AllowUserToDeleteRows = false;
            this.reportDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.reportDGV.BackgroundColor = System.Drawing.Color.White;
            this.reportDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.reportDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reportDGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reportDGV.GridColor = System.Drawing.Color.White;
            this.reportDGV.Location = new System.Drawing.Point(0, 0);
            this.reportDGV.MultiSelect = false;
            this.reportDGV.Name = "reportDGV";
            this.reportDGV.ReadOnly = true;
            this.reportDGV.RowHeadersWidth = 62;
            this.reportDGV.RowTemplate.Height = 28;
            this.reportDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.reportDGV.Size = new System.Drawing.Size(1276, 601);
            this.reportDGV.TabIndex = 0;
            this.reportDGV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.reportDGV_CellClick);
            // 
            // searchPanel6
            // 
            this.searchPanel6.BackColor = System.Drawing.Color.White;
            this.searchPanel6.Controls.Add(this.groupBox11);
            this.searchPanel6.Controls.Add(this.groupBox12);
            this.searchPanel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.searchPanel6.Location = new System.Drawing.Point(0, 0);
            this.searchPanel6.Name = "searchPanel6";
            this.searchPanel6.Size = new System.Drawing.Size(1276, 72);
            this.searchPanel6.TabIndex = 1;
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.Color.White;
            this.groupBox11.Controls.Add(this.Button16);
            this.groupBox11.Controls.Add(this.Button18);
            this.groupBox11.Controls.Add(this.Button17);
            this.groupBox11.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox11.ForeColor = System.Drawing.Color.Black;
            this.groupBox11.Location = new System.Drawing.Point(654, 0);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(622, 72);
            this.groupBox11.TabIndex = 2;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Управление заявками";
            // 
            // groupBox12
            // 
            this.groupBox12.BackColor = System.Drawing.Color.White;
            this.groupBox12.Controls.Add(this.TextBox6);
            this.groupBox12.Controls.Add(this.label12);
            this.groupBox12.Controls.Add(this.ComboBox6);
            this.groupBox12.Controls.Add(this.label13);
            this.groupBox12.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox12.ForeColor = System.Drawing.Color.Black;
            this.groupBox12.Location = new System.Drawing.Point(0, 0);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(622, 72);
            this.groupBox12.TabIndex = 1;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Поиск";
            // 
            // TextBox6
            // 
            this.TextBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TextBox6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBox6.ForeColor = System.Drawing.Color.Black;
            this.TextBox6.Location = new System.Drawing.Point(368, 29);
            this.TextBox6.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.TextBox6.Name = "TextBox6";
            this.TextBox6.Size = new System.Drawing.Size(232, 23);
            this.TextBox6.TabIndex = 4;
            this.TextBox6.TextChanged += new System.EventHandler(this.searchReportTextBox_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(297, 32);
            this.label12.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 19);
            this.label12.TabIndex = 3;
            this.label12.Text = "Значение:";
            // 
            // ComboBox6
            // 
            this.ComboBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ComboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ComboBox6.ForeColor = System.Drawing.Color.Black;
            this.ComboBox6.FormattingEnabled = true;
            this.ComboBox6.Items.AddRange(new object[] {
            "По номеру отчета",
            "По номеру заявки",
            "По ФИО"});
            this.ComboBox6.Location = new System.Drawing.Point(111, 29);
            this.ComboBox6.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.ComboBox6.Name = "ComboBox6";
            this.ComboBox6.Size = new System.Drawing.Size(166, 23);
            this.ComboBox6.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(21, 32);
            this.label13.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(90, 19);
            this.label13.TabIndex = 2;
            this.label13.Text = "Фильтрация:";
            // 
            // notifyIcon
            // 
            this.notifyIcon.BalloonTipText = "Уведомление!";
            this.notifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon.Icon")));
            this.notifyIcon.Text = "notifyIcon1";
            this.notifyIcon.Visible = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1284, 761);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximumSize = new System.Drawing.Size(1300, 800);
            this.MinimumSize = new System.Drawing.Size(1280, 800);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Главная";
            this.Load += new System.EventHandler(this.mainForm_Load);
            this.statisticTabPage.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartFaultStats)).EndInit();
            this.kpiPanel.ResumeLayout(false);
            this.specialistTabPage.ResumeLayout(false);
            this.specialistPanel.ResumeLayout(false);
            this.tablePanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.specialistDGV)).EndInit();
            this.searchPanel4.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.clientTabPage.ResumeLayout(false);
            this.clientPanel.ResumeLayout(false);
            this.tablePanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.clientDGV)).EndInit();
            this.searchPanel3.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.equipmentTabPage.ResumeLayout(false);
            this.equipmentPanel.ResumeLayout(false);
            this.tablePanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.equipmentDGV)).EndInit();
            this.searchPanel2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.requestTabPage.ResumeLayout(false);
            this.tablePanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView)).EndInit();
            this.searchPanel.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl.ResumeLayout(false);
            this.commentTabPage.ResumeLayout(false);
            this.tabelPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.commentDGV)).EndInit();
            this.searchPanel5.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.reportTabPage.ResumeLayout(false);
            this.tablePanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.reportDGV)).EndInit();
            this.searchPanel6.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Button1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.TabPage statisticTabPage;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TabPage specialistTabPage;
        private System.Windows.Forms.TabPage clientTabPage;
        private System.Windows.Forms.TabPage equipmentTabPage;
        private System.Windows.Forms.Panel equipmentPanel;
        private System.Windows.Forms.TabPage requestTabPage;
        private System.Windows.Forms.Panel tablePanel;
        private System.Windows.Forms.DataGridView DataGridView;
        private System.Windows.Forms.Panel searchPanel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox TextBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox ComboBox1;
        public System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Panel searchPanel2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Button7;
        private System.Windows.Forms.Button Button9;
        private System.Windows.Forms.Button Button8;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox TextBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox ComboBox3;
        public System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel tablePanel2;
        private System.Windows.Forms.DataGridView equipmentDGV;
        private System.Windows.Forms.Panel clientPanel;
        private System.Windows.Forms.Panel tablePanel3;
        private System.Windows.Forms.DataGridView clientDGV;
        private System.Windows.Forms.Panel searchPanel3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button Button10;
        private System.Windows.Forms.Button Button12;
        private System.Windows.Forms.Button Button11;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox TextBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox ComboBox4;
        public System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel specialistPanel;
        private System.Windows.Forms.Panel tablePanel4;
        private System.Windows.Forms.DataGridView specialistDGV;
        private System.Windows.Forms.Panel searchPanel4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button Button13;
        private System.Windows.Forms.Button Button15;
        private System.Windows.Forms.Button Button14;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox TextBox5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox ComboBox5;
        public System.Windows.Forms.Label label9;
        private System.Windows.Forms.NotifyIcon notifyIcon;
        private System.Windows.Forms.TabPage commentTabPage;
        private System.Windows.Forms.Panel tabelPanel5;
        private System.Windows.Forms.DataGridView commentDGV;
        private System.Windows.Forms.Panel searchPanel5;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button Button4;
        private System.Windows.Forms.Button Button6;
        private System.Windows.Forms.Button Button5;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox TextBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox ComboBox2;
        public System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage reportTabPage;
        private System.Windows.Forms.Panel tablePanel6;
        private System.Windows.Forms.DataGridView reportDGV;
        private System.Windows.Forms.Panel searchPanel6;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button Button16;
        private System.Windows.Forms.Button Button18;
        private System.Windows.Forms.Button Button17;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox TextBox6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox ComboBox6;
        public System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label avgTimeLabel;
        private System.Windows.Forms.Label completedCountLabel;
        private System.Windows.Forms.Panel kpiPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}