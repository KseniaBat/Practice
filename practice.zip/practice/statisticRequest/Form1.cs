﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace statisticRequest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void authorizeButton_Click(object sender, EventArgs e)
        {
            string login = TextBox1.Text;
            string password = TextBox2.Text;
            if (login.Length == 0 || password.Length == 0)
            {
                MessageBox.Show("Заполните данные",
                                "Ошибка!", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }

            string query = @"
                            SELECT role, linked_id
                            FROM [user]
                            WHERE username = @username AND password = @pass";
            date.OpenConnection();
            using (var cmd = new SqlCommand(query, date.Connection))
            {
                cmd.Parameters.AddWithValue("@username", login);
                cmd.Parameters.AddWithValue("@pass", password);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        data.role = reader["role"].ToString();
                        data.linked_id = reader["linked_id"] as int? ?? 0;

                   
                        Properties.Settings.Default.Save();

                        date.CloseConnection();
                        this.DialogResult = DialogResult.OK;
                        return;
                    }
                }
            }
            date.CloseConnection();
            MessageBox.Show("Неверный логин или пароль",
                            "Ошибка!", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
        }

        private void loginForm_Load(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.RememberMe)
            {
          
                TextBox1.Text = Properties.Settings.Default.SavedLogin;
                TextBox2.Text = Properties.Settings.Default.SavedPassword;
            }
        }
    }
}
