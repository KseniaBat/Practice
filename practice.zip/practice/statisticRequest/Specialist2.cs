﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace statisticRequest
{
    public partial class Specialist2 : Form
    {
        public Specialist2()
        {
            InitializeComponent();
        }

        private void editSpecialist_Load(object sender, EventArgs e)
        {
            loadComponent();
        }

        public void loadComponent()
        {
            string query = $@"SELECT full_name, email, phone FROM specialist WHERE specialist_id = {data.indexSpecialist}";

            using (SqlCommand cmd = new SqlCommand(query, date.Connection))
            {
                cmd.Parameters.AddWithValue("@id", data.indexSpecialist);

                date.OpenConnection();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        textBox1.Text = reader["full_name"].ToString();
                        textBox3.Text = reader["email"].ToString();
                        textBox2.Text = reader["phone"].ToString();
                    }
                }

                date.CloseConnection();
            }
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text.Trim();
            string phone = textBox2.Text.Trim();
            string email = textBox3.Text.Trim();

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(phone) || string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("Заполните все поля.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = @"UPDATE specialist 
                                 SET full_name = @name, 
                                     email = @email, 
                                     phone = @phone 
                                 WHERE specialist_id = @id";

                using (SqlCommand cmd = new SqlCommand(query, date.Connection))
                {
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@phone", phone);
                    cmd.Parameters.AddWithValue("@id", data.indexSpecialist);

                    date.OpenConnection();
                    int result = cmd.ExecuteNonQuery();
                    date.CloseConnection();

                    if (result > 0)
                    {
                        MessageBox.Show("Специалист обновлен.", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Обновление не удалось.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                date.CloseConnection();
                MessageBox.Show("Ошибка при обновлении: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void groupBox_Enter(object sender, EventArgs e)
        {

        }
    }
}
